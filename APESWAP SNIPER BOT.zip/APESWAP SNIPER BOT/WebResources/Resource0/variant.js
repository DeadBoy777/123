{
    "onboarding": [{
        "range": [
            1,
            500
        ],
        "variant": "201510_On_Boarding_No_Show_Ctrl"
    }, {
        "range": [
            501,
            1000
        ],
        "variant": "201510_On_Boarding_Show_Test"
    }]
}