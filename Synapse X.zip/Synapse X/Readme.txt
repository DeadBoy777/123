1. Download the archive 
2. Open the Loader.exe file PASS - newsoft2022
3. Open the software
4. Have a nice day!
▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬